export const getLoginPath = () => "login"; //post
export const getProfileDetailsPath = () => "profile_detail"; //post
export const getMyBookingPath = () => "/my_upcoming_bookings"; //post
export const getCompletedBookingPath = () => "/my_completed_bookings"; //post
export const getinprogressBookingPath = () => "/my_underprogress_bookings"; //post
export const getRegisterUser = () => "register"; //post
export const getOtp = () => "Verify_otp"; //post
