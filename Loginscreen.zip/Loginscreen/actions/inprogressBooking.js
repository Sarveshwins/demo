import {basicActions} from './includes/BasicActions';
export const attemptinprogressBookingActions = basicActions(
  'ATTEMPT_INPROGRES_BOOKING',
);
