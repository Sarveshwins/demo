import {basicActions} from './includes/BasicActions';
export const attemptUserRegisterActions = basicActions('ATTEMPT_USERREGISTER');
