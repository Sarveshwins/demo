import {basicActions} from './includes/BasicActions';
export const attemptBookingActions = basicActions('ATTEMPT_BOOKING');
