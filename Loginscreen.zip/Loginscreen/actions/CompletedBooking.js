import {basicActions} from './includes/BasicActions';
export const attemptCompletBookingActions = basicActions(
  'ATTEMPT_COMPLETED_BOOKING',
);
