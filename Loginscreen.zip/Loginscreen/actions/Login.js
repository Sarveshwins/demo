import {basicActions} from './includes/BasicActions';
export const attemptLoginActions = basicActions('ATTEMPT_LOGIN');
