import { basicActions } from "./includes/BasicActions";
export const attemptOtpActions = basicActions("ATTEMPT_OTP");
