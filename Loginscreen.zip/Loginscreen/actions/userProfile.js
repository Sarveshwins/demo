import {basicActions} from './includes/BasicActions';
export const attemptprofileActions = basicActions('ATTEMPT_USERPROFILE');
