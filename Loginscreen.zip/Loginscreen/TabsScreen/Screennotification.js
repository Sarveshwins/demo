import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Screennotification = () => {
  return (
    <View style={{flex: 1, justifyContent: 'center'}}>
      <Text style={{textAlign: 'center', fontSize: 45}}>
        {' '}
        Notification Screen
      </Text>
    </View>
  );
};

export default Screennotification;

const styles = StyleSheet.create({});
