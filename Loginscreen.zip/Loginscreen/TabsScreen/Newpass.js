import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const Newpass = () => {
    return (
        <View>
            <Text>New password</Text>
            <Text>confirm password</Text>
        </View>
    )
}

export default Newpass

const styles = StyleSheet.create({})
